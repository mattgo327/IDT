<?php
    return [
        'url' => 'http://localhost/leccion37/'
    ];
    // vamos retornar un array y ese lo vamos a guardar en una variable
    // y desde esa varible usamos las posicion 'url'
    // eso es gracias a que es un array asociativo